import React from 'react';
import {useCurrentFrame, interpolate, AbsoluteFill, spring} from 'remotion';

export const LiminalTitleSequence: React.FC = () => {
  const frame = useCurrentFrame();
  
  // Animation parameters
  const fps = 30;
  const durationInFrames = 150;
  
  // Title text animation - scale and opacity
  const titleScale = interpolate(frame, [0, 20], [0.8, 1], {
    extrapolateRight: 'clamp'
  });
  
  const titleOpacity = interpolate(frame, [0, 30, 60], [0, 1, 1], {
    extrapolateLeft: 'clamp',
    extrapolateRight: 'clamp'
  });
  
  // Particle generation
  const particleCount = 50;
  const particles = [];
  
  for (let i = 0; i < particleCount; i++) {
    const startX = Math.random() * 1920;
    const startY = Math.random() * 1080;
    const duration = 60 + Math.random() * 40;
    const delay = Math.random() * 30;
    
    // Calculate particle movement
    const x = interpolate(frame - delay, [0, duration], [startX, startX + (Math.random() - 0.5) * 800]);
    const y = interpolate(frame - delay, [0, duration], [startY, startY + (Math.random() - 0.5) * 600 + 300]);
    const scale = interpolate(frame - delay, [0, 10, duration - 10, duration], [0, 1, 1, 0]);
    const opacity = interpolate(frame - delay, [0, 5, duration - 5, duration], [0, 1, 1, 0]);
    
    // Color variation (dark red to orange gradient)
    const hue = interpolate(frame - delay, [0, 30], [0, 45]);
    const color = `hsl(${hue}, 70%, 60%)`;
    
    particles.push(
      <div
        key={i}
        style={{
          position: 'absolute',
          left: x,
          top: y,
          width: 8 + Math.random() * 12,
          height: 8 + Math.random() * 12,
          backgroundColor: color,
          borderRadius: '50%',
          transform: `translate(-50%, -50%) scale(${scale})`,
          opacity,
          filter: 'blur(0.3px)'
        }}
      />
    );
  }
  
  return (
    <AbsoluteFill style={{backgroundColor: '#0a0a12', overflow: 'hidden'}}>
      {/* Background gradient overlay */}
      <div
        style={{
          position: 'absolute',
          top: 0,
          left: 0,
          width: '100%',
          height: '100%',
          background: 'linear-gradient(135deg, #0a0a12 0%, #141424 50%, #0a0a12 100%)',
          zIndex: -1
        }}
      />
      
      {/* Particle system */}
      {particles}
      
      {/* Title text */}
      <div
        style={{
          position: 'absolute',
          top: '50%',
          left: '50%',
          transform: `translate(-50%, -50%) scale(${titleScale})`,
          opacity: titleOpacity,
          zIndex: 10
        }}
      >
        <span 
          style={{
            fontFamily: '"Inter", "Roboto", sans-serif',
            fontWeight: 900,
            fontSize: '128px',
            color: '#ffffff',
            textShadow: '0 0 40px rgba(255, 60, 0, 0.3), 0 0 80px rgba(255, 60, 0, 0.15)',
            letterSpacing: '-4px'
          }}
        >
          LIMINAL
        </span>
      </div>
      
      {/* Subtitle for context */}
      <div
        style={{
          position: 'absolute',
          top: interpolate(frame, [0, 70], [600, 580]),
          left: '50%',
          transform: `translateX(-50%)`,
          opacity: interpolate(frame, [60, 80, 120], [0, 1, 0]),
          zIndex: 10
        }}
      >
        <span 
          style={{
            fontFamily: '"Inter", "Roboto", sans-serif',
            fontWeight: 400,
            fontSize: '32px',
            color: '#ffffff',
            textShadow: '0 0 20px rgba(0, 0, 0, 0.5)'
          }}
        >
          VIDEO EDITOR
        </span>
      </div>
    </AbsoluteFill>
  );
};