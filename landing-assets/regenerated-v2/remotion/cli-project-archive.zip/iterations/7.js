precision highp float;

uniform vec2 u_resolution;
uniform float u_time;
uniform vec2 u_mouse;

#define PI 3.14159265359

mat2 rot(float a) {
    float s = sin(a), c = cos(a);
    return mat2(c, -s, s, c);
}

float hash(vec2 p) {
    return fract(sin(dot(p, vec2(127.1, 311.7))) * 43758.5453);
}

float noise(vec2 p) {
    vec2 i = floor(p);
    vec2 f = fract(p);
    f = f * f * (3.0 - 2.0 * f);
    
    float a = hash(i);
    float b = hash(i + vec2(1.0, 0.0));
    float c = hash(i + vec2(0.0, 1.0));
    float d = hash(i + vec2(1.0, 1.0));
    
    return mix(mix(a, b, f.x), mix(c, d, f.x), f.y);
}

float fbm(vec2 p) {
    float v = 0.0;
    float a = 0.5;
    mat2 m = mat2(1.6, 1.2, -1.2, 1.6);
    
    for(int i = 0; i < 5; i++) {
        v += a * noise(p);
        p = m * p;
        a *= 0.5;
    }
    return v;
}

float warpedFbm(vec2 p, float t) {
    vec2 q = vec2(fbm(p + vec2(0.0, 0.0)),
                  fbm(p + vec2(5.2, 1.3)));
    
    vec2 r = vec2(fbm(p + 4.0 * q + vec2(1.7, 9.2) + 0.15 * t),
                  fbm(p + 4.0 * q + vec2(8.3, 2.8) + 0.126 * t));
    
    return fbm(p + 4.0 * r);
}

vec3 palette(float t) {
    vec3 a = vec3(0.5, 0.5, 0.5);
    vec3 b = vec3(0.5, 0.5, 0.5);
    vec3 c = vec3(1.0, 1.0, 1.0);
    vec3 d = vec3(0.263, 0.416, 0.557);
    
    return a + b * cos(6.28318 * (c * t + d));
}

vec3 palette2(float t) {
    vec3 a = vec3(0.8, 0.5, 0.4);
    vec3 b = vec3(0.2, 0.4, 0.2);
    vec3 c = vec3(2.0, 1.0, 1.0);
    vec3 d = vec3(0.0, 0.25, 0.25);
    
    return a + b * cos(6.28318 * (c * t + d));
}

void main() {
    vec2 uv = (gl_FragCoord.xy - 0.5 * u_resolution.xy) / min(u_resolution.x, u_resolution.y);
    vec2 p = uv * 3.0;
    
    float t = u_time * 0.3;
    
    vec2 mouse = u_mouse * 2.0 - 1.0;
    p += mouse * 0.5;
    
    float warp1 = warpedFbm(p, t);
    float warp2 = warpedFbm(p * 1.5 + vec2(10.0), t * 1.2);
    float warp3 = warpedFbm(p * 0.7 - vec2(20.0), t * 0.8);
    
    vec3 col1 = palette(warp1);
    vec3 col2 = palette2(warp2);
    vec3 col3 = palette(warp3 * 2.0);
    
    vec3 final = mix(col1, col2, 0.5 + 0.5 * sin(t));
    final = mix(final, col3, 0.3 + 0.3 * cos(t * 0.7));
    
    float edge = length(uv);
    final *= 1.0 - edge * 0.5;
    
    float glow = pow(warp1 * warp2, 2.0) * 0.5;
    final += glow * vec3(0.2, 0.4, 0.6);
    
    float scan = sin(uv.y * 200.0 + t * 10.0) * 0.02;
    final += scan;
    
    final = pow(final, vec3(0.9));
    final *= 1.2;
    
    gl_FragColor = vec4(final, 1.0);
}